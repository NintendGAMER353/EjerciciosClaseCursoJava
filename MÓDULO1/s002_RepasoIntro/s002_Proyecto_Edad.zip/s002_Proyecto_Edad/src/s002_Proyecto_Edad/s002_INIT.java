package s002_Proyecto_Edad;

public class s002_INIT {
	public static void main(String[] args) {
		String nombre = "Francisco Jesús Domínguez";
		int edad = 21;

		if(edad>18) {
			System.out.println(nombre + " \nMayor de edad " + edad + " años");
		}else {
			System.out.println(nombre + " \nMenor de edad " + edad + " años");
		}
	}
}
